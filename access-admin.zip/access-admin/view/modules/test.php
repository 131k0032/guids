<?php 

echo $_POST["tour_date"];


 ?>