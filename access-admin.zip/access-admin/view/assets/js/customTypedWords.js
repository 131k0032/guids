            
var typed = new Typed('.typed-words', {
      strings: ["Guías privados","Tours","Experiencias", "Momentos"],
      typeSpeed: 80,
      backSpeed: 80,
      backDelay: 4000,
      startDelay: 1000,
      loop: true,
      showCursor: true
});      