<?php	

$lang = array(
	
# =====================================
# =           HOME TEMPLATE           =
# =====================================

//Header user no logged
"Registro"=>"Signup",
"Iniciar sesión"=>"Singin",
"Español"=>"Spanish",
"Inglés"=>"English",
"Cambiar idioma"=>"Change language",
//Header user logged
"Agenda"=>"Booking",
"Más opciones"=>"More options",
"Avisos"=>"Notifications",
"Perfil"=>"Profile",
"Agregar tour"=>"Add tour",
"Mis tours"=>"My tours",
"Generar seguro grupal"=>"Generate insurance",
"Configurar"=>"Setting",
"Cerrar sesión"=>"Logout",
"Español"=>"Spanish",
"Inglés"=>"English",
"Cambiar idioma"=>"Change language",
//Search section
"Encuentra" => "Find ",
//Content section
"Tours"=>"Tours"
	



# ======  End of HOME TEMPLATE  =======


	

	
);