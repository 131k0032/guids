   
 $(document).ready(function() {
        $('#mytours').DataTable();
  } );
    
  