<?php

$lang = array(
	
# =====================================
# =           HOME TEMPLATE           =
# =====================================

//Header user no logged
"Registro"=>"Registro",
"Iniciar sesión"=>"Iniciar sesión",
"Español"=>"Español",
"Inglés"=>"Inglés",
"Cambiar idioma"=>"Cambiar idioma",
// Header user logged
"Agenda"=>"Agenda",
"Más opciones"=>"Más opciones",
"Avisos"=>"Avisos",
"Perfil"=>"Perfil",
"Agregar tour"=>"Agregar tour",
"Mis tours"=>"Mis tours",
"Generar seguro grupal"=>"Generar seguro grupal",
"Configurar"=>"Configurar",
"Cerrar sesión"=>"Cerrar sesión",
"Español"=>"Español",
"Inglés"=>"Inglés",
"Cambiar idioma"=>"Cambiar idioma",
//Search section
"Encuentra" => "Encuentra ",
//Content section
"Tours"=>"Tours"
# ======  End of HOME TEMPLATE  =======


	

	
);